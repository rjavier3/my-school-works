# Assignment 5 - Webpack with React

Please read the instructions in the [assignment PDF](dmit2008-assignment-05.pdf)

Any other instructions should be specified by your instructor.
